# Project medizon

# Note: This project is just for the submission of the course project. This is not developed for any business purpose or internal or external benefits.