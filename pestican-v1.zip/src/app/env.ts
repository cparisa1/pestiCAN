/* For Development API URL */
//export const API_URL = 'http://localhost:5000';


/* For Production API URL */
export const API_URL = 'http://99.79.129.247';